﻿/*Equipo: 06
 * Integrantes: 
 * Baeza Álvarez Isaura
 * Castañeda Aranda Alma Adriana 
 * Cote Valencia Alexis Daniel
 * Oronzor Montes Manases Leonel 
 * Recinos Hernández Luis Mario
 * Fecha: 10/09/2021
 * ACtividad 5-Práctica01
 * Descripción: Programa que pide el nombre del usuario 
 * y lo ocupa para cordialmente saludarle

Realizado por Recinos Hernández Luis Mario*/
using System;
namespace Laboratorio1
{
    class Program
    {
        static void Main(string[] args)
        {
            string buenNombre;
            Console.WriteLine("Hola mundo desde Visual Studio");
            Console.WriteLine("Por favor ingrese su nombre, necesito saludarle");
            buenNombre = Console.ReadLine();
            Console.WriteLine("Vale, gracias :)");
            Console.WriteLine("¿Cómo estás hoy " + buenNombre +"?");
        }
    }
}
